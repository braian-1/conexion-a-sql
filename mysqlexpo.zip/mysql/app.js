import express from 'express';
import { cargarCSV } from './employeeService.js';
import cors from 'cors';
import db from './db.js';


const app = express();

app.use(express.json())
app.use(cors())

//const archivo = 'empleados.csv';
//cargarCSV(archivo);

//agregar usuarios
app.post('/employee', async (req, res) => {
    const datos = req.body;
    const query = `INSERT INTO employees(name,lastname,lastname2,email,charge,city,salary,age)
    VALUES(?,?,?,?,?,?,?,?);
    `;
    const valores = [
        datos.name,
        datos.lastname,
        datos.lastname2,
        datos.email,
        datos.charge,
        datos.city,
        datos.salary,
        datos.age
    ];

    db.query(query, valores, (err, result) => {
        if (err) {
            console.error("error al insertar", err.message);
            return;
        }
        res.status(201).json({
            idEmployee: result.insertId
        });
    });
});

//endpoint uploadData
app.post('/uploadCSV', (req, res) => {
    uploadCSVBack();
    console.log("funciono");
    res.json({result: "bd actualizada"});
})

//obtener todos los clientes
app.get('/getEmployees', (req, res) => {
    const sql = 'SELECT * FROM employees;'

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error al obtener los empleados:', err);
            return res.status(500).json({ error: 'Error al obtener los empleados' });
        }
        res.json(results);
    });
});

app.get('/getEmployees/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM employees WHERE idEmployee = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error('Error al obtener empleado:', err);
            return res.status(500).json({ error: 'Error al obtener empleado' });
        }
        if (result.length === 0) {
            return res.status(404).json({ message: 'Empleado no encontrado' });
        }
        res.json(result[0]);
    });
});

// ------------------ UPDATE ------------------
app.put('/employee/:id', (req, res) => {
    const { id } = req.params;
    const datos = req.body;

    const query = `
        UPDATE employees
        SET name=?, lastname=?, lastname2=?, email=?, charge=?, city=?, salary=?, age=?
        WHERE idEmployee=?
    `;
    const valores = [
        datos.name,
        datos.lastname,
        datos.lastname2,
        datos.email,
        datos.charge,
        datos.city,
        datos.salary,
        datos.age,
        id
    ];

    db.query(query, valores, (err, result) => {
        if (err) {
            console.error("Error al actualizar:", err.message);
            return res.status(500).json({ error: "Error al actualizar empleado" });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Empleado no encontrado" });
        }
        res.json({ message: "Empleado actualizado correctamente" });
    });
});

// ------------------ DELETE ------------------
app.delete('/employee/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM employees WHERE idEmployee = ?';

    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error("Error al eliminar:", err.message);
            return res.status(500).json({ error: "Error al eliminar empleado" });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Empleado no encontrado" });
        }
        res.json({ message: "Empleado eliminado correctamente" });
    });
});

//port
app.listen(3000, () => {
    console.log("puerto corriendo")
});