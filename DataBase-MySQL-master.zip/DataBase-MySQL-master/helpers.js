import fs from 'fs';
import { fileURLToPath } from 'url';
import path, { dirname } from 'path';
import csv from 'csv-parser';
import connection from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const uploadCSVBack = async () =>{
    const result = [];
    const filePath = path.join(__dirname, 'empleados.csv');

    fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (empleado) => {
        const query = `INSERT INTO employees(name,lastname,lastname2,email,charge,city,salary,age) VALUES (?,?,?,?,?,?,?,?)`
        
        const values = [
            empleado.Nombre,
            empleado.Apellido,
            empleado.Apellido2,
            empleado.Correo,
            empleado.Cargo,
            empleado.Ciudad,
            empleado.Salario,
            empleado.Edad
        ]

        connection.query(query,values, (error,result) => {
            if(error){
                console.error('Error al insertar', error);
            }else{
                console.log('Empleado agregado exitosamente', result);
            }
        })
    })
}
