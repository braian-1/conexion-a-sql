import express from 'express';
import csv from 'csv-parser';
import bodyParser from 'body-parser';
import db from './db.js';
import cors from 'cors';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { uploadCSVBack } from './helpers.js';
const app = express();
app.use(express.json());
app.use(bodyParser.json());
app.use(cors());
const upload = multer({ dest: 'uploads/' });


app.get('/empleados', (req,res) => {
    db.query('SELECT * FROM employees', (err,results,fields) => {
        if(err) throw err;
        res.json(results)
        })
})

app.post('/empleados', (req, res) => {
    const persona = req.body;
    const VALUES = [
        persona.name, 
        persona.lastname,
        persona.lastname2,
        persona.email,
        persona.charge,
        persona.city,
        persona.salary,
        persona.age
]

    const insertQuery = `
        INSERT INTO employees(name, lastname, lastname2, email, charge, city, salary, age)
        VALUES (?,?,?,?,?,?,?,?)
     `

    ;
    db.query(insertQuery, VALUES, (err) => {
    if (err) {
        console.error('Error al insertar:', err.message);
        res.status(500).json({ mensaje: '❌ Error al insertar empleado' });
    } else {
        console.log('✅ Inserción correcta.');
        res.status(200).json({ mensaje: '✅ Empleado insertado correctamente' });
    }
});
});

//Editar usuario

app.put('/empleados/:id', (req, res) => {
    const { id } = req.params; // ID del empleado a modificar
    const persona = req.body;

    const updateQuery = `
        UPDATE employees 
        SET name = ?, 
            lastname = ?, 
            lastname2 = ?, 
            email = ?, 
            charge = ?, 
            city = ?, 
            salary = ?, 
            age = ?
        WHERE idEmployee = ?
    `;

    const VALUES = [
        persona.name,
        persona.lastname,
        persona.lastname2,
        persona.email,
        persona.charge,
        persona.city,
        persona.salary,
        persona.age,
        id
    ];

    db.query(updateQuery, VALUES, (err, result) => {
        if (err) {
            console.error('❌ Error al actualizar:', err.message);
            res.status(500).json({ mensaje: '❌ Error al actualizar empleado' });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ mensaje: '⚠️ Empleado no encontrado' });
        } else {
            console.log('✅ Actualización correcta.');
            res.status(200).json({ mensaje: '✅ Empleado actualizado correctamente' });
        }
    });
});

// Obtener un solo empleado por ID
app.get('/empleados/:id', (req, res) => {
    const { id } = req.params;
    db.query('SELECT * FROM employees WHERE idEmployee = ?', [id], (err, results) => {
        if (err) {
            console.error('Error al obtener empleado:', err.message);
            return res.status(500).json({ mensaje: 'Error al obtener empleado' });
        }
        if (results.length === 0) {
            return res.status(404).json({ mensaje: 'Empleado no encontrado' });
        }
        res.json(results[0]); // enviamos el primer resultado
    });
});

// Borrar un empleado por ID
app.delete('/empleados/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM employees WHERE idEmployee = ?', [id], (err, result) => {
        if (err) {
            console.error('Error al eliminar empleado:', err.message);
            return res.status(500).json({ mensaje: 'Error al eliminar empleado' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ mensaje: 'Empleado no encontrado' });
        }
        res.json({ mensaje: 'Empleado eliminado correctamente' });
    });
});

// Endpoint para subir CSV
app.post('/uploadCSV', upload.single('csvFile'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ 
            success: false, 
            message: 'No se subió ningún archivo' 
        });
    }

    const filePath = path.resolve(req.file.path);
    let errors = [];
    let successCount = 0;

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            const query = `
                INSERT INTO employees(
                    name, lastname, lastname2, email, 
                    charge, city, salary, age
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;
            
            const values = [
                row.Nombre || null,
                row.Apellido || null,
                row.Apellido2 || null,
                row.Correo || null,
                row.Cargo || null,
                row.Ciudad || null,
                parseFloat(row.Salario) || null,
                parseInt(row.Edad) || null
            ];

            db.query(query, values, (error) => {
                if (error) {
                    errors.push({
                        row,
                        error: error.message
                    });
                } else {
                    successCount++;
                }
            });
        })
        .on('end', () => {
            fs.unlinkSync(filePath); // Eliminar archivo temporal
            
            if (errors.length > 0) {
                return res.status(207).json({ // 207 Multi-Status
                    success: false,
                    message: 'Algunos registros fallaron',
                    succeeded: successCount,
                    failed: errors.length,
                    errors: errors.slice(0, 5) // Mostrar solo primeros 5 errores
                });
            }
            
            res.json({ 
                success: true,
                message: `CSV procesado correctamente. ${successCount} registros insertados.`
            });
        })
        .on('error', (error) => {
            fs.unlinkSync(filePath);
            res.status(500).json({
                success: false,
                message: 'Error al procesar el archivo',
                error: error.message
            });
        });
});



app.listen(3000, () => {
    console.log('Servidor encendido')
});