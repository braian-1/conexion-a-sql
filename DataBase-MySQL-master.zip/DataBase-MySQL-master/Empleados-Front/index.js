document.addEventListener('DOMContentLoaded', () => {
    const table = document.getElementById('tablaEmpleados');
    const btnAgregar = document.getElementById('btnAgregar');
    const btnUpload = document.getElementById('btnUpload');
    const fileInput = document.getElementById('csvFile');

    // Cargar empleados al iniciar
    cargarEmpleados();

    // Evento para agregar empleado
    btnAgregar.addEventListener("click", () => {
        mostrarFormulario();
    });

    // Evento para subir CSV
    btnUpload.addEventListener('click', subirCSV);

    // Delegación de eventos para la tabla
    table.addEventListener("click", manejarAccionesTabla);

    // ========== FUNCIONES PRINCIPALES ========== //

    async function subirCSV() {
        if (!fileInput.files || fileInput.files.length === 0) {
            alert('⚠️ Por favor selecciona un archivo CSV');
            return;
        }

        const file = fileInput.files[0];
        
        if (!file.name.endsWith('.csv')) {
            alert('❌ El archivo debe ser un CSV (.csv)');
            return;
        }

        const formData = new FormData();
        formData.append('csvFile', file);

        try {
            const response = await fetch('http://localhost:3000/uploadCSV', {
                method: 'POST',
            });

            const result = await response.json();
            
            if (response.ok) {
                alert('✅ Archivo CSV subido correctamente');
                cargarEmpleados(); // Actualizar la tabla
            } else {
                throw new Error(result.message || 'Error al subir el archivo');
            }
        } catch (error) {
            console.error('Error:', error);
            alert(`🚫 Error: ${error.message}`);
        }
    }

    function manejarAccionesTabla(e) {
        if (e.target.classList.contains("btn-update")) {
            const idEmpleado = e.target.dataset.id;
            fetch(`http://localhost:3000/empleados/${idEmpleado}`)
                .then(res => res.json())
                .then(empleado => mostrarFormulario(empleado, idEmpleado))
                .catch(err => console.error("Error al obtener empleado:", err));
        }
        
        if (e.target.classList.contains("btn-delete")) {
            const idEmpleado = e.target.dataset.id;
            if (!confirm("¿Seguro que quieres eliminar este empleado?")) return;

            fetch(`http://localhost:3000/empleados/${idEmpleado}`, { method: "DELETE" })
                .then(res => res.json())
                .then(data => {
                    alert(data.mensaje || "Empleado eliminado correctamente");
                    cargarEmpleados();
                })
                .catch(err => console.error("Error eliminando:", err));
        }
    }

    document.getElementById('btnUpload').addEventListener('click', async () => {
    const fileInput = document.getElementById('csvFile');
    const statusDiv = document.getElementById('status');
    
    if (!fileInput.files || fileInput.files.length === 0) {
        statusDiv.textContent = '⚠️ Selecciona un archivo CSV';
        return;
    }
    
    const formData = new FormData();
    formData.append('csvFile', fileInput.files[0]);
    
    try {
        statusDiv.textContent = '⏳ Procesando archivo...';
        statusDiv.style.color = 'blue';
        
        const response = await fetch('http://localhost:3000/uploadCSV', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || 'Error al subir archivo');
        }
        
        statusDiv.textContent = `✅ ${result.message}`;
        statusDiv.style.color = 'green';
        
        // Actualizar la lista de empleados
        cargarEmpleados();
        
    } catch (error) {
        console.error('Error:', error);
        statusDiv.textContent = `❌ ${error.message}`;
        statusDiv.style.color = 'red';
    }
});

    // ========== FUNCIONES AUXILIARES ========== //

    function cargarEmpleados() {
        fetch('http://localhost:3000/empleados')
            .then(res => res.json())
            .then(data => {
                table.innerHTML = '';
                data.forEach(rec => {
                    table.innerHTML += `
                    <tr>
                        <td>${rec.name}</td>
                        <td>${rec.lastname}</td>
                        <td>${rec.lastname2}</td>
                        <td>${rec.email}</td>
                        <td>${rec.charge}</td>
                        <td>${rec.city}</td>
                        <td>${rec.salary}</td>
                        <td>${rec.age}</td>
                        <td>
                            <button type="button" class="btn btn-secondary btn-update" data-id="${rec.idEmployee}">
                                Editar empleado
                            </button>
                        </td>
                        <td>
                            <button type="button" class="btn btn-danger btn-delete" data-id="${rec.idEmployee}">
                                Eliminar empleado
                            </button>
                        </td>
                    </tr>
                    `;
                });
            })
            .catch(err => console.error("Error cargando empleados:", err));
    }

    function mostrarFormulario(empleado = {}, id = null) {
        const formContainer = document.getElementById('form-container');
        formContainer.innerHTML = `
            <form id="formEmpleado">
                <input type="text" id="nombre" placeholder="Nombre" value="${empleado.name || ''}" required />
                <input type="text" id="apellido" placeholder="Apellido" value="${empleado.lastname || ''}" required />
                <input type="text" id="apellido2" placeholder="Segundo Apellido" value="${empleado.lastname2 || ''}" required />
                <input type="email" id="email" placeholder="Correo electrónico" value="${empleado.email || ''}" required />
                <input type="text" id="charge" placeholder="Cargo" value="${empleado.charge || ''}" required />
                <input type="text" id="ciudad" placeholder="Ciudad" value="${empleado.city || ''}" required />
                <input type="number" id="salario" placeholder="Salario" value="${empleado.salary || ''}" required />
                <input type="text" id="edad" placeholder="Edad" value="${empleado.age || ''}" required />
                <button type="submit">${id ? 'Actualizar' : 'Guardar'}</button>
            </form>
        `;
        
        document.getElementById("formEmpleado").addEventListener("submit", async (e) => {
            e.preventDefault();
            await guardarEmpleado(id);
        });
    }

    async function guardarEmpleado(id) {
        const empleadoData = {
            name: document.getElementById("nombre").value,
            lastname: document.getElementById("apellido").value,
            lastname2: document.getElementById("apellido2").value,
            email: document.getElementById("email").value,
            charge: document.getElementById("charge").value,
            city: document.getElementById("ciudad").value,
            salary: parseFloat(document.getElementById("salario").value),
            age: parseInt(document.getElementById("edad").value)
        };

        try {
            const url = id 
                ? `http://localhost:3000/empleados/${id}`
                : `http://localhost:3000/empleados`;

            const method = id ? "PUT" : "POST";

            const res = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(empleadoData)
            });

            if (!res.ok) throw new Error("Error al guardar");

            alert(id ? "Empleado actualizado" : "Empleado agregado");
            document.getElementById('form-container').innerHTML = '';
            cargarEmpleados();

        } catch (error) {
            console.error(error);
            alert("Ocurrió un error al guardar");
        }
    }
});


